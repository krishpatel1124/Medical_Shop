<?php

session_start();
include("../../config/db.php");

// ==========================================
// CHECK ADMIN LOGIN
// ==========================================

if (!isset($_SESSION['admin_id'])) {
    header("Location: ../login.php");
    exit();
}

// ==========================================
// ONLY POST REQUEST
// ==========================================

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: details.php");
    exit();
}


// ==========================================
// GET FORM DATA
// ==========================================

$order_id = isset($_POST['order_id'])
    ? (int)$_POST['order_id']
    : 0;

$order_status = isset($_POST['order_status'])
    ? mysqli_real_escape_string($conn, $_POST['order_status'])
    : '';

$payment_status = isset($_POST['payment_status'])
    ? mysqli_real_escape_string($conn, $_POST['payment_status'])
    : '';


// ==========================================
// VALIDATION
// ==========================================

if ($order_id <= 0) {
    die("Invalid Order ID.");
}

if ($order_status == '') {
    die("Order status is required.");
}

if ($payment_status == '') {
    die("Payment status is required.");
}


// ==========================================
// GET CUSTOMER ID FROM ORDER
// ==========================================

$customerQuery = mysqli_query(
    $conn,
    "SELECT customer_id
     FROM `order`
     WHERE order_id='$order_id'
     LIMIT 1"
);

if (!$customerQuery) {
    die(
        "Customer query failed: " .
        htmlspecialchars(mysqli_error($conn))
    );
}

if (mysqli_num_rows($customerQuery) == 0) {
    die("Order not found.");
}

$orderData = mysqli_fetch_assoc($customerQuery);

$customer_id = (int)$orderData['customer_id'];


// ==========================================
// CHECK CUSTOMER EXISTS
// ==========================================

$customerCheck = mysqli_query(
    $conn,
    "SELECT customer_id
     FROM customer_detail
     WHERE customer_id='$customer_id'
     LIMIT 1"
);

if (!$customerCheck) {
    die(
        "Customer check failed: " .
        htmlspecialchars(mysqli_error($conn))
    );
}

if (mysqli_num_rows($customerCheck) == 0) {
    die("Customer does not exist.");
}


// ==========================================
// UPDATE ORDER STATUS
// ==========================================

$orderSql = "UPDATE `order`
             SET order_status='$order_status'
             WHERE order_id='$order_id'";

if (!mysqli_query($conn, $orderSql)) {

    die(
        "Order update failed: " .
        htmlspecialchars(mysqli_error($conn))
    );
}


// ==========================================
// CHECK PAYMENT RECORD
// ==========================================

$checkPayment = mysqli_query(
    $conn,
    "SELECT payment_id
     FROM payment
     WHERE order_id='$order_id'
     LIMIT 1"
);

if (!$checkPayment) {
    die(
        "Payment check failed: " .
        htmlspecialchars(mysqli_error($conn))
    );
}


// ==========================================
// PAYMENT EXISTS
// ==========================================

if (mysqli_num_rows($checkPayment) > 0) {

    $paymentSql = "UPDATE payment
                   SET payment_status='$payment_status'
                   WHERE order_id='$order_id'";

    if (!mysqli_query($conn, $paymentSql)) {

        die(
            "Payment update failed: " .
            htmlspecialchars(mysqli_error($conn))
        );
    }

}


// ==========================================
// PAYMENT DOES NOT EXIST
// ==========================================

else {

    // Generate unique transaction ID
    $transaction_id = 'COD-' . $order_id . '-' . time();

    $paymentSql = "INSERT INTO payment
                   (
                       order_id,
                       customer_id,
                       payment_method,
                       payment_status,
                       transaction_id
                   )
                   VALUES
                   (
                       '$order_id',
                       '$customer_id',
                       'COD',
                       '$payment_status',
                       '$transaction_id'
                   )";

    if (!mysqli_query($conn, $paymentSql)) {

        die(
            "Payment insert failed: " .
            htmlspecialchars(mysqli_error($conn))
        );
    }
}


// ==========================================
// SUCCESS
// ==========================================

header("Location: details.php?id=$order_id&updated=1");
exit();

?>